# orion-aurora

Emerald accent on dark green. For variety.

Part of Orion OS. See `docs/design-system.md` at the repository root
for the full design language.

## Files

- `tokens.json` — color ramps for this theme (subset of
  `desktop/orion-framework/data/tokens.json`).
- `theme.json` — Orion Desktop theme metadata.
- `gtk.css` — GTK3+ CSS extracted from the same tokens. Drop into
  `~/.themes/orion-aurora/gtk-3.0/gtk.css` to apply.
- `sddm.theme` — Orion SDDM theme definition.

## License

CC-BY-SA-4.0 for the artwork; GPL-3.0-or-later for the JSON/CSS code.
